<?php
header("Content-Type: application/json");

$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "akademik";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}

// Fungsi respon untuk API
function response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

// Pastikan koneksi database berhasil
if (!$koneksi) {
    response(["error" => "Database connection failed"], 500);
}

// Parsing URL
$url = $_SERVER['REQUEST_URI'];
$parts = explode("/", trim($url, "/")); // Pisahkan URL menjadi array berdasarkan "/"
$apiIndex = array_search("api", $parts); // Cari posisi folder "api"
if ($apiIndex === false || $parts[$apiIndex + 1] !== "index.php") {
    response(["error" => "Invalid API endpoint"], 404);
}

// Ambil nama tabel dan ID dari URL
$table = $parts[$apiIndex + 2] ?? null; // Nama tabel setelah /api/index.php/
$id = $parts[$apiIndex + 3] ?? null;    // ID setelah /{tabel}/

// Pemetaan nama tabel dari URL ke database
$tableMap = [
    "mahasiswa" => "mahasiswa",
    "dosen" => "dosen",
    "fakultas" => "fakultas",
    "ruangan" => "ruangan",
    "semester" => "semester"
];

$idColumnMap = [
    "mahasiswa" => "id",
    "dosen" => "id",
    "fakultas" => "id",
    "ruangan" => "id",
    "semester" => "id"
];

// Validasi tabel
if (!isset($tableMap[$table])) {
    response(["error" => "Table not found", "received_table" => $table, "available_tables" => array_keys($tableMap)], 404);
}
$table = $tableMap[$table];

// Metode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Operasi CRUD berdasarkan metode
switch ($method) {
    case "GET":
        if ($id) {
            // Ambil nama kolom ID yang sesuai
            $idColumn = $idColumnMap[$table] ?? null;
            if (!$idColumn) response(["error" => "Invalid table ID column"], 500);
    
            // Query untuk mengambil data berdasarkan ID
            $query = "SELECT * FROM $table WHERE $idColumn = ?";
            $stmt = $koneksi->prepare($query);
            if (!$stmt) response(["error" => "Failed to prepare statement"], 500);
            $stmt->bind_param("i", $id);
        } else {
            // Query untuk mengambil semua data
            $query = "SELECT * FROM $table";
            $stmt = $koneksi->prepare($query);
            if (!$stmt) response(["error" => "Failed to prepare statement"], 500);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        response($data);
        break;
    
    case "POST":
        $input = json_decode(file_get_contents("php://input"), true);
        if (!$input) response(["error" => "Invalid input"], 400);
        
        $fields = implode(",", array_keys($input));
        $placeholders = implode(",", array_fill(0, count($input), "?"));
        $values = array_values($input);
        $types = str_repeat("s", count($values));

        $query = "INSERT INTO $table ($fields) VALUES ($placeholders)";
        $stmt = $koneksi->prepare($query);
        if (!$stmt) response(["error" => "Failed to prepare statement"], 500);
        $stmt->bind_param($types, ...$values);
        if ($stmt->execute()) {
            response(["message" => "Data created", "id" => $stmt->insert_id], 201);
        } else {
            response(["error" => "Failed to create data"], 400);
        }
        break;

        case "PUT":
            if (!$id) response(["error" => "ID is required"], 400);
            $input = json_decode(file_get_contents("php://input"), true);
            if (!$input) response(["error" => "Invalid input"], 400);
        
            $fields = implode(" = ?, ", array_keys($input)) . " = ?";
            $values = array_values($input);
            $types = str_repeat("s", count($values));
            $values[] = $id;
            $types .= "i";
        
            // Dapatkan kolom ID yang sesuai untuk tabel
            $idColumn = $idColumnMap[$table] ?? null;
            if (!$idColumn) response(["error" => "Invalid table ID column"], 500);
        
            // Query untuk update
            $query = "UPDATE $table SET $fields WHERE $idColumn = ?";
            $stmt = $koneksi->prepare($query);
            if (!$stmt) response(["error" => "Failed to prepare statement"], 500);
            $stmt->bind_param($types, ...$values);
            if ($stmt->execute()) {
                response(["message" => "Data updated"]);
            } else {
                response(["error" => "Failed to update data"], 400);
            }
            break;
        


            case "DELETE":
                if (!$id) response(["error" => "ID is required"], 400);
            
                // Ambil nama kolom ID yang sesuai
                $idColumn = $idColumnMap[$table] ?? null;
                if (!$idColumn) response(["error" => "Invalid table ID column"], 500);
            
                // Query untuk menghapus data berdasarkan ID
                $query = "DELETE FROM $table WHERE $idColumn = ?";
                $stmt = $koneksi->prepare($query);
                if (!$stmt) response(["error" => "Failed to prepare statement"], 500);
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    response(["message" => "Data deleted"]);
                } else {
                    response(["error" => "Failed to delete data"], 400);
                }
                break;
            
}
?>